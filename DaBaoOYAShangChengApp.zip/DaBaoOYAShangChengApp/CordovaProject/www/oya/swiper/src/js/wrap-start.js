(function () {
    'use strict';
    var $;