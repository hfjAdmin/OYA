;jQuery(function() {
	var mBtn=$(".icon-icon");
				var header=$(".headmenu");
				 mBtn.on("click",function(){
				 	header.toggle();
				 })
});